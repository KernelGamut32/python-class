from collections import defaultdict
from order_system.models.customer import Customer
from typing import List

class Database():
    def __init__(self):
        self.customers = {}

    def get_by_id(self, id):
        return self.customers[id] if id in self.customers else None

    def get_all(self):
        results = []
        for c in self.customers.values():
            results.append(c)
        return results

    def insert_customer(self, customer: Customer):
        self.customers[str(customer.id)] = customer

    def update_customer(self, id, customer: Customer):
        if id in self.customers:
            self.customers[id] = customer
            return True
        else:
            return False

    def delete_customer(self, id):
        if id in self.customers:
            del self.customers[id]
            return True
        else:
            return False
