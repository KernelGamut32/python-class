export interface Address {
  id: number;
  address: string;
  city: string;
  state: string;
  zip_code: string;
}
