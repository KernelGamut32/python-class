def calculate(quantity, unit_cost):
    if quantity >= 100:
        discount = 0.25
    elif quantity >= 50 and quantity < 100:
        discount = 0.1
    else:
        discount = 0.0
    subtotal = quantity * unit_cost
    total_tax = subtotal * 1.075
    total_discount = total_tax * (1 - discount)
    return subtotal, total_tax, total_discount

part_num = input('Part Number: ')
try:
    quantity = int(input('Quantity: '))
except ValueError:
    quantity = 10
    print('Invalid quantity - defaulted to 10')
try:
    unit_cost = float(input('Unit Cost: '))
except ValueError:
    unit_cost = 0.0
    print('Invalid unit cost - defaulted to $0.00')
subtotal, total_tax, total_discount = calculate(quantity, unit_cost)
print('Part Number', part_num)
print(f'\t{quantity} at ${unit_cost:,.2f} per:')
print(f'\tSubtotal:\t\t${subtotal:>10,.2f}')
print(f'\tTotal (with Tax):\t${total_tax:>10,.2f}')
print(f'\tTotal (with Discount):\t${total_discount:>10,.2f}')
