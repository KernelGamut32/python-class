from widget.widget import Widget

def func1():
    wi1 = Widget('w2')
    wi1 = Widget('w3')
    wi1.list_all_names()

def func2():
    wi2 = Widget('w5')
    wi2 = Widget('w6')
    wi2.list_all_names()

wo1 = Widget('w1')
wo1.list_all_names()
func1()
wo1.list_all_names()
wo2 = Widget('w4')
wo2.list_all_names()
func2()
wo2.list_all_names()