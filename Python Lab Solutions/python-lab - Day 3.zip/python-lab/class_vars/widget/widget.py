class Widget():
    list_of_names = []

    def __init__(self, name):
        self.name = name
        self.__class__.list_of_names.append(name)

    def __del__(self):
        print('in destructor')
        self.__class__.list_of_names.remove(self.name)

    @classmethod
    def list_all_names(cls):
        print(cls.list_of_names)