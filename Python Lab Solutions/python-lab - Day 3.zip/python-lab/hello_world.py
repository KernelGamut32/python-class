for i in range(0, 10, 3):
    print(i)