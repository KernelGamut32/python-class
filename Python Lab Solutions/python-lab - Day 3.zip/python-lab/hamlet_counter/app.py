import re
import sys
from collections import Counter

if len(sys.argv) != 2:
    raise SystemExit(f'Usage: {sys.argv[0]} <filename>')

def countwords(filename):
    with open(filename) as hamlet:
        full_text = hamlet.read().lower().replace('\n', ' ')
        full_text = re.sub(r'[^a-z ]', '', full_text)
    words = full_text.split()
    return Counter(words)

print(countwords(sys.argv[1]).most_common(10))