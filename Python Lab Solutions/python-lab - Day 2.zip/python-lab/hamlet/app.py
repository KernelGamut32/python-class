import re
import sys

if len(sys.argv) != 2:
    raise SystemExit(f'Usage: {sys.argv[0]} <filename>')

def countwords(filename):
    wordcounts = {}
    with open(filename) as hamlet:
        for line in hamlet:
            line = line.lower()
            line = re.sub(r'[^a-z ]', '', line)
            words = line.split()
            for word in words:
                wordcounts[word] = wordcounts.get(word, 0) + 1
    return wordcounts

def sortwordcounts(wordcounts):
    return dict(sorted(wordcounts.items(), key=lambda x:x[1], reverse=True))

results = sortwordcounts(countwords(sys.argv[1]))
keys = list(results.keys())[:30]
values = list(results.values())[:30]
for i, k in enumerate(keys):
    print(k, values[i])