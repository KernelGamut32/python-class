first_name = input('What is your first name? ')
last_name = input('What is your last name? ')
try:
    age = float(input('How old are you? '))
except ValueError:
    age = 0
    print("Bad age")
try:
    num_years = int(input('How many years of experience do you have? '))
except ValueError:
    num_years = 0
job_title = input('What is your job title? ')
print(first_name, '\n', last_name, '\n', age)
print(f'{last_name}, {first_name} ({age} year(s) old)')
print(f'Working as {job_title} for {num_years:>3d} years')