translations = {
    'M': 1000,
    'D': 500,
	'C': 100,
	'L': 50,
	'X': 10,
	'V': 5,
	'I': 1
}

def translate(number):
    '''
    This function blah, blah, blah...
    '''
    arabic_vals = [0 for _ in range(len(number) + 1)]
    for i, c in enumerate(number):
        arabic_vals[i] = translations.get(c.upper(), 0)
    print('Before:', arabic_vals)
    total = 0
    for i in range(len(number)):
        if arabic_vals[i] < arabic_vals[i + 1]:
            arabic_vals[i] = -arabic_vals[i]
        total += arabic_vals[i]
    print('After', arabic_vals)
    return total

numeral = input('Enter a Roman Numeral: ')
print(translate(numeral))
print(help(translate))
