def addition(op1, op2):
    return op1 + op2

def subtraction(op1, op2):
    return op1 - op2

def multiplication(op1, op2):
    return op1 * op2

def division(op1, op2):
    return op1 / op2

ops = {
    '+': addition,
    '-': subtraction,
    '*': multiplication,
    '/': division
}

equation = input('Operation? ')
parts = equation.split(' ')
# print(parts)
if len(parts) != 3 or parts[1] not in ops:
    print('Invalid operation specified')
else:
    # f = ops[parts[1]]
    # num1 = int(parts[0])
    # num2 = int(parts[2])
    # print(f(num1, num2))
    print(ops[parts[1]](int(parts[0]), int(parts[2])))
