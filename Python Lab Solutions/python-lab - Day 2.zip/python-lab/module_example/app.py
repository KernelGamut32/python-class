from demo_module import demo_module
demo_module.dummy()
