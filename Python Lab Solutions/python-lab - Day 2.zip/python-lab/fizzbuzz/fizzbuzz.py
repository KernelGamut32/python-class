try:
    val = int(input('What whole number do you want to evaluate? '))
except ValueError:
    print('Invalid input - defaulting to 100')
    val = 100

for v in range(1, val + 1):
    if v % 15 == 0:
        print('fizzbuzz')
    elif v % 3 == 0:
        print('fizz')
    elif v % 5 == 0:
        print('buzz')
    else:
        print(v)