valid = False
while not valid:
    try:
        num = int(input("What number? "))
        valid = True
    except ValueError:
        print('invalid input - enter whole number only please')

def collatz(num):
    if num < 1:
        return [], False
    results = [num]
    while (num > 1):
        num = int(num / 2 if num % 2 == 0 else num * 3 + 1)
        results.append(num)
    return results, True

results, status = collatz(num)
if not status:
    print('Collatz failed')
else:
    for index, num in enumerate(results):
        print(f'{num:>5d}', end = ' ')
        if (index + 1) % 10 == 0 or index == len(results) - 1:
            print()
    print('Total steps:', len(results))
