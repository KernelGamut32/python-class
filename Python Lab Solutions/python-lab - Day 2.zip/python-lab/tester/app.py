from calculator import calculator

calc = calculator.Calc()
calc.add(5)
calc.add(10)
calc.add(4, 3)
print(calc.showcalc())

calc.add(2, 5)
calc.add(9)
calc.mult(13)
calc.mult(20, 5)
calc.pow(3)
print(calc)
calc.ac()
calc.add(1)
calc.pow(3)