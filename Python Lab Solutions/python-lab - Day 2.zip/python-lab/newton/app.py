valid = False
while not valid:
    num = float(input("What number? "))
    if num <= 0:
        print('invalid input - positive number only please')
    else:
        valid = True

def newton(num):
    guess = 1.0
    for _ in range(1, 11):
        guess = guess - (pow(guess, 2) - num)/(2 * guess)
        print(guess)
    
    return guess

print(newton(num))