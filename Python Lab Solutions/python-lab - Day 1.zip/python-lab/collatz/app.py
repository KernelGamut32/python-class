valid = False
while not valid:
    try:
        num = int(input("What number? "))
        valid = True
    except ValueError:
        print('invalid input - enter whole number only please')

def collatz(num):
    if num < 1:
        return False
    count = 1
    while (num > 1):
        print(f'{num:>5d}', end = ' ')
        num = int(num / 2 if num % 2 == 0 else num * 3 + 1)
        if count % 10 == 0:
            print()
        count += 1
    print(f'{1:>5d}')
    print('Total steps:', count)
    return True

if not collatz(num):
    print('Collatz failed')