valid = False
while not valid:
    try:
        num = int(input("What number? "))
        if num < 0:
            print('invalid input - non-negative number only please')
        else:
            valid = True
    except ValueError:
        print('invalid input - enter whole number only please')

def factorial(num):
    if num == 0:
        return 1
    result = num
    for i in range(num - 1, 0, -1):
        result *= i
    return result

print(factorial(num))