from collections import namedtuple

Card = namedtuple('Card', ['rank', 'suit'])

suits = ['clubs', 'spades', 'hearts', 'diamonds']
special_ranks = {
    1: 'A',
    11: 'J',
    12: 'Q',
    13: 'K'    
}

cards = []

for suit in suits:
    for c in range(1, 14):
        cards.append(Card(suit=suit, rank=special_ranks[c] if c in special_ranks else c))

print(cards)