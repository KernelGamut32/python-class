words = [
    'apple', 'pear', 'Abraham Lincoln', ' ', '', '', \
    'banana', 'Darth Vader', 'Ebenezer Scrooge', 'ice cream', 'lime', \
    'zebra', 'outpost', 'Yellowstone', 'Umbrella Academy'
]

print(list(filter(lambda w:w.lower()[:1] in ['a', 'e', 'i', 'o', 'u'], words)))