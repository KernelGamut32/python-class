class Widget():
    __list_of_names = []
    __how_many = 0

    def __init__(self, name):
        self.name = name
        self.__class__.__list_of_names.append(name)
        self.__class__.__how_many += 1

    def __del__(self):
        self.__class__.__list_of_names.remove(self.name)
        self.__class__.__how_many -= 1

    @classmethod
    def list_all_names(cls):
        return cls.__list_of_names
    
    @classmethod
    def get_count(cls):
        return cls.__how_many