from widget.widget import Widget

def func1():
    wi1 = Widget('w2')
    wi1 = Widget('w3')
    print(Widget.list_all_names())
    print(Widget.get_count())

def func2():
    wi2 = Widget('w5')
    wi2 = Widget('w6')
    print(Widget.list_all_names())
    print(Widget.get_count())

wo1 = Widget('w1')
print(Widget.list_all_names())
print(Widget.get_count())
func1()
print(Widget.list_all_names())
print(Widget.get_count())
wo2 = Widget('w4')
print(Widget.list_all_names())
print(Widget.get_count())
func2()
print(Widget.list_all_names())
print(Widget.get_count())
