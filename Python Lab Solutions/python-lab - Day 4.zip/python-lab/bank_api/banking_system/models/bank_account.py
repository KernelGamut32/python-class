from pydantic import BaseModel

class BankAccount(BaseModel):
    id: int
    name_on_account: str
    account_number: str
    balance: float
    is_overdrawn: bool