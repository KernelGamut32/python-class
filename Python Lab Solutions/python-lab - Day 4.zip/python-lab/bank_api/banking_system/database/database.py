from banking_system.models.bank_account import BankAccount

class Database():
    def __init__(self):
        self.accounts = {}

    def get_by_id(self, id):
        return self.accounts[id] if id in self.accounts else None

    def get_all(self):
        results = []
        for c in self.accounts.values():
            results.append(c)
        return results

    def insert_account(self, account: BankAccount):
        self.accounts[str(account.id)] = account

    def update_account(self, id, account: BankAccount):
        if id != str(account.id):
            return False

        if id in self.accounts:
            self.accounts[id] = account
            return True
        else:
            return False

    def delete_account(self, id):
        if id in self.accounts:
            del self.accounts[id]
            return True
        else:
            return False
