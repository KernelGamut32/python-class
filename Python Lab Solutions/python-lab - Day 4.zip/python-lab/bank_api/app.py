import uvicorn
from fastapi import FastAPI
from banking_system.database.database import Database
from banking_system.models.bank_account import BankAccount
from typing import List

app = FastAPI()

database = Database()

@app.post("/accounts")
async def insert_account(account: BankAccount):
    database.insert_account(account)
    return account

@app.get("/accounts/{id}")
async def get_account_by_id(id):
    account = database.get_by_id(id)
    if account:
        return account
    else:
        return {}

@app.get('/accounts', response_model=List[BankAccount])
async def get_all_accounts():
    return database.get_all()

@app.put('/accounts/{id}')
async def update_account(id, body: BankAccount):
    if database.update_account(id, body):
        return {'message': 'Account updated successfully'}
    else:
        return {'message': 'Account not found'}

@app.delete('/accounts/{id}')
async def delete_account(id):
    if database.delete_account(id):
        return {'message': 'Account deleted successfully'}
    else:
        return {'message': 'Account not found'}

if __name__ == "__main__":
    uvicorn.run("app:app",host="0.0.0.0",port=8080,reload=True,timeout_keep_alive=3600,debug=True,workers=10)