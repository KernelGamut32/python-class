from functools import partial

print_no_nl = partial(print, end='')
print_no_sp = partial(print, sep='-')
sorted_r = partial(sorted, reverse=True)

for i in range(10):
    print(i)

for i in range(10):
    print_no_nl(i)
print()

print('09', '23', '2021')
print_no_sp('09', '23', '2021')

values = [1, -18, 35, 4, 1000, -8000, 82, 100, 2, 3, 4, 5]

print(sorted(values))
print(sorted_r(values))