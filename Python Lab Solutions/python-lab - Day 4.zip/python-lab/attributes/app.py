from whatchamacallit.whatchamacallit import Whatchamacallit

w = Whatchamacallit('hello')
w.value = 'howdy'
w.otherprop = 'changed'
w.value = 'bienvenuto'
w.value = 'sup'
print(w.value, w.value_counter)

w.value_counter = 18
print(w.value, w.value_counter)

print(w.vale)
w.value = 8
print(w.value, w.value_counter)