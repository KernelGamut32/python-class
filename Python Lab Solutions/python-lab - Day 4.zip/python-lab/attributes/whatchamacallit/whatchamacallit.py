class Whatchamacallit():
    def __init__(self, value):
        super().__setattr__('value_counter', 0)
        self.value = value
        self.otherprop = ''

    def __getattr__(self, attr):
        if attr in self.__dict__:
            return self.__dict__[attr]
        else:
            return 'invalid property specified'
        
    def __setattr__(self, attr, value):
        if attr == 'value':
            super().__setattr__('value_counter', self.value_counter + 1)
            self.__dict__[attr] = value
        elif attr != 'value_counter':
            self.__dict__[attr] = value
        else:
            print('not so fast - denied!')