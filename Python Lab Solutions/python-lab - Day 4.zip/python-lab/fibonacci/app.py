def fibonacci(num_vals):
    if num_vals < 2:
        return [], False
    nums = [1, 1]
    for i in range(2, num_vals):
        nums.append(nums[i-1] + nums[i-2])
    # Could also use instead:
    # for _ in range(2, num_vals):
    #    nums.append(nums[-1] + nums[-2])
    return nums, True

valid = False
while not valid:
    try:
        num_vals = int(input("How many Fibonacci numbers would you like? "))
        valid = True
    except ValueError:
        print('invalid input - enter whole number only please')

fibs, status = fibonacci(num_vals)
if not status:
    print('Could not complete Fibonacci request')
else:
    print(fibs)