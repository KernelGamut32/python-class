from zany_int.zany_int import ZanyInt

x = 4
zi1 = ZanyInt(4)

# print(len(x))
print(len(zi1))

print(zi1)
print(zi1)
print(zi1)

zi2 = ZanyInt(3)

print(zi2)
print(zi2)
print(zi2)

print(zi1 + zi2)
print(zi1 + zi2)
print(zi1 + zi2)