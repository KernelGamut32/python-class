import random

class ZanyInt(int):
    def __len__(self):
        return len(repr(self))

    def __str__(self):
        if self == 3:
            return 'three'
        if random.random() <= 0.5:
            return 'blah'
        return repr(self)

    def __add__(self, other):
        result = super().__add__(other)
        if random.random() <= 0.25:
            result += 0.99
        return result