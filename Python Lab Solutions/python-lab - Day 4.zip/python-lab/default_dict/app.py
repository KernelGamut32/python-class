from collections import defaultdict
import sys

if len(sys.argv) != 2:
    raise SystemExit(f'Usage: {sys.argv[0]} <filename>')

def countfruits(filename):
    fruitcounts = defaultdict(list)
    with open(filename) as fruits:
        for line in fruits:
            parts = line.split()
            fruitcounts[parts[0]].append(parts[1])
    return fruitcounts

print(countfruits(sys.argv[1]))