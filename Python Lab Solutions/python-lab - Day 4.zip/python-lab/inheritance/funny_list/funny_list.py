class FunnyList(list):
    # def __init__(self):
    #     print('Created')

    def __init__(self, item=None):
        print('Created')
        if item:
            if type(item) == list:
                super().__init__(item)
            else:
                super().__init__([item])

    def __eq__(self, other):
        """Check for equality without concern for order.
           If the sorted versions of two FunnyLists are the
           same, then we deem the FunnyLists to be the same.
        """
        # return sorted(self) == sorted(other)
        # print(self)
        # print(other)
        result = sorted(self) == sorted(other)
        # result = self.sort() == other.sort()
        # print(self)
        # print(other)
        return result

    def __ne__(self, other):
        return sorted(self) != sorted(other)
