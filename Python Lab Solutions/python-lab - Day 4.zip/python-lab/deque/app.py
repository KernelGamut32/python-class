import sys
from collections import deque

if len(sys.argv) != 2:
    raise SystemExit(f'Usage: {sys.argv[0]} <filename>')

def tail(filename, num_lines):
    s = deque('', maxlen=num_lines)
    with open(filename) as hamlet:
        for line in hamlet:
            line = line.strip('\n')
            if line:
                s.append(line)
    return s

print(tail(sys.argv[1], 10))
print()
print(list(filter(lambda l:l.lower().find('the') >= 0, tail(sys.argv[1], 10))))