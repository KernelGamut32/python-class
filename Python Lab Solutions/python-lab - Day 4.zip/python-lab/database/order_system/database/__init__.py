import sqlite3
conn = sqlite3.connect('orders.db')

print("Opened database successfully");

conn.execute('''CREATE TABLE IF NOT EXISTS CUSTOMER
         (ID INTEGER PRIMARY KEY AUTOINCREMENT,
         FIRST_NAME           TEXT    NOT NULL,
         LAST_NAME           TEXT    NOT NULL,
         ADDRESS           TEXT    NOT NULL,
         CITY           TEXT    NOT NULL,
         STATE           TEXT    NOT NULL,
         ZIP           TEXT    NOT NULL);''')
print("Customers table created successfully");

conn.close()