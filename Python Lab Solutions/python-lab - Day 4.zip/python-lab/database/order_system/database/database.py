import sqlite3
from order_system.models.customer import Customer

class Database():
    def get_by_id(self, id):
        with sqlite3.connect('orders.db') as db:
            cursor = db.execute('SELECT ID, FIRST_NAME, LAST_NAME, ADDRESS, CITY, STATE, ZIP FROM CUSTOMER WHERE ID=?;', id)
        row = cursor.fetchone()
        return Customer(id=row[0], first_name=row[1], last_name=row[2], address=row[3], city=row[4], state=row[5], zip=row[6])

    def get_all(self):
        results = []
        with sqlite3.connect('orders.db') as db:
            cursor = db.execute('SELECT ID, FIRST_NAME, LAST_NAME, ADDRESS, CITY, STATE, ZIP FROM CUSTOMER;')
        rows = cursor.fetchall()
        for row in rows:
            results.append(Customer(id=row[0], first_name=row[1], last_name=row[2], address=row[3], city=row[4], state=row[5], zip=row[6]))
        return results

    def insert_customer(self, customer: Customer):
        with sqlite3.connect('orders.db') as db:
            db.execute('INSERT INTO CUSTOMER (FIRST_NAME, LAST_NAME, ADDRESS, CITY, STATE, ZIP) VALUES \
                (?, ?, ?, ?, ?, ?)', [customer.first_name, customer.last_name, customer.address, \
                customer.city, customer.state, customer.zip])

    def update_customer(self, id, customer: Customer):
        if id != str(customer.id):
            return False

        with sqlite3.connect('orders.db') as db:
            db.execute('UPDATE CUSTOMER SET FIRST_NAME=?, LAST_NAME=?, ADDRESS=?, CITY=?, STATE=?, ZIP=? \
                WHERE ID=?;', [customer.first_name, customer.last_name, customer.address, \
                customer.city, customer.state, customer.zip, customer.id])
        return True

    def delete_customer(self, id):
        with sqlite3.connect('orders.db') as db:
            db.execute('DELETE FROM CUSTOMER WHERE ID=?;', id)
        return True
