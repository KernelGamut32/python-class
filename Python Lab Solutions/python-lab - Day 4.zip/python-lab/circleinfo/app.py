import math

def circleinfo(radius):
    return math.pi * radius * radius, 2 * math.pi * radius

radius = 3.998
area, circumference = circleinfo(radius)
print(f'Radius: {radius:.3f}, Area: {area: .3f}, Circumference: {circumference: .3f}')