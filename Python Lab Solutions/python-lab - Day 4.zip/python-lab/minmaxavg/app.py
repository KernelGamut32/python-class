def minmaxavg(nums):
    if len(nums) == 0:
        return 0.0, 0.0, 0.0
    return min(nums), max(nums), sum(nums) / len(nums)

valid = False
while not valid:
    try:
        num_vals = int(input("How many numbers? "))
        valid = True
    except ValueError:
        print('invalid input - enter whole number only please')

nums = []

for i in range(num_vals):
    valid = False
    while not valid:
        try:
            val = float(input("Input next number? "))
            valid = True
        except ValueError:
            print('invalid input - enter numbers only please')
    nums.append(val)

print(minmaxavg(nums))