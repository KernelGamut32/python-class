import uvicorn
from fastapi import FastAPI, Request
from order_system.database.database import Database
from order_system.models.customer import Customer
from typing import List

app = FastAPI()

database = Database()

@app.get("/")
async def root():
    return {'message': 'Hello World!!'}

@app.post("/customers")
async def insert_customer(customer: Customer):
    database.insert_customer(customer)
    return customer

@app.get("/customers/{id}")
async def get_customer_by_id(id):
    customer = database.get_by_id(id)
    if customer:
        return customer
        # return database.get_by_id(id)
    else:
        return {}

@app.get('/customers', response_model=List[Customer])
async def get_all_customers():
    return database.get_all()

@app.put('/customers/{id}')
async def update_customer(id, body: Customer):
    if database.update_customer(id, body):
        return {'message': 'Customer updated successfully'}
    else:
        return {'message': 'Customer not found'}

@app.delete('/customers/{id}')
async def delete_customer(id):
    if database.delete_customer(id):
        return {'message': 'Customer deleted successfully'}
    else:
        return {'message': 'Customer not found'}

if __name__ == "__main__":
    uvicorn.run("app:app",host="0.0.0.0",port=8080,reload=True,timeout_keep_alive=3600,debug=True,workers=10)